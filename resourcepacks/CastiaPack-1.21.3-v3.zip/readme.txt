NOTICE:
All artwork within this resource pack is the property of Oxywire (with the exception of fancyPants shaders and part of our emojis by Amber Wat).
Oxywire is the company that operates CastiaMC.
You MAY NOT use this artwork anywhere outside of CastiaMC's services, and you may not distribute it without consent.


3rd PARTY CONTRIBUTORS:

Helped with some textures:
 - FeignedIgnorance
 - RoraPookie
 - S0L
 - Euie
 - Ginger
 - LemonBeee

Shader for custom armor textures:
 - https://github.com/Ancientkingg/fancyPants

Part of the emojis
 - https://github.com/AmberWat/PixelTwemojiMC-18

Copyright © CastiaMC / Oxywire.